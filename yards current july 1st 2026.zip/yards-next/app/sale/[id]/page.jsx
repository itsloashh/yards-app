"use client";
import { useState, useEffect, useRef, Suspense } from "react";
import { useRouter, useParams, useSearchParams } from "next/navigation";
import { ChevronLeft, ChevronRight, Heart, Clock, MapPin, Navigation, Star, Phone, Mail, MessageCircle, Trash2, Edit, Share2, AlertCircle, Eye, Rocket, Sparkles, Loader2, Flag, Shield } from "lucide-react";
import { useApp } from "@/lib/AppContext";
import { haversine, fmtDist } from "@/lib/distance";
import { formatSaleDate } from "@/lib/timeFormat";
import { isBoosted } from "@/lib/boostPackages";
import BoostModal from "@/components/BoostModal";
import ShareModal from "@/components/ShareModal";
import ReportModal from "@/components/ReportModal";
import ReviewsModal from "@/components/ReviewsModal";
import Avatar from "@/components/Avatar";
import { getSaleType } from "@/lib/saleTypes";

export default function SaleDetailPage() {
  return (
    <Suspense fallback={<div className="flex items-center justify-center" style={{ minHeight: "50vh" }}><Loader2 className="w-8 h-8 text-emerald-500 animate-spin" /></div>}>
      <SaleDetailInner />
    </Suspense>
  );
}

function SaleDetailInner() {
  const router = useRouter();
  const { id } = useParams();
  const searchParams = useSearchParams();
  const { sales, loc, unit, toggleSaved, isSaved, user, handleDeleteSale, incrementSaleViews, profile, loadSales } = useApp();
  const [photo, setPhoto] = useState(0);
  const [showContact, setShowContact] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [showBoost, setShowBoost] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [showReviews, setShowReviews] = useState(false);
  const [boostBanner, setBoostBanner] = useState(null); // "success" | "cancelled" | null
  const touchStartX = useRef(null);
  const touchStartY = useRef(null);
  const viewTracked = useRef(false);

  // Read ?boost=success / ?boost=cancelled from the Stripe redirect
  useEffect(() => {
    const b = searchParams.get("boost");
    if (b === "success" || b === "cancelled") {
      setBoostBanner(b);
      // Clean the URL so a refresh doesn't re-show it
      window.history.replaceState({}, "", window.location.pathname);
    }
  }, [searchParams]);

  const sale = sales.find(s => s.id === id || s.id === parseInt(id));

  // Track a view once per page visit (skips owner's own views, handled in the context)
  useEffect(() => {
    if (sale && !viewTracked.current) {
      viewTracked.current = true;
      incrementSaleViews(sale.id, sale);
    }
  }, [sale]);

  if (!sale) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center" style={{ minHeight: "50vh" }}>
        <h3 className="text-lg font-bold text-stone-800 mb-2 font-display">Sale Not Found</h3>
        <p className="text-stone-500 text-sm mb-4">This sale may have ended or been removed.</p>
        <button onClick={() => router.push("/")} className="text-emerald-600 font-semibold hover:underline">Browse Sales</button>
      </div>
    );
  }

  const useKm = unit === "km";
  const distance = loc ? haversine(loc.lat, loc.lng, sale.coords.lat, sale.coords.lng, useKm) : 0;
  const distText = loc ? fmtDist(distance, unit) : "";
  const saved = isSaved(sale.id);
  const isOwner = user && sale.userId === user.id;
  const saleBoosted = isBoosted(sale.boostedUntil);
  const tf = profile?.time_format === "24h" ? "24h" : "12h";
  const displayDate = sale.dateRaw
    ? formatSaleDate(sale.dateRaw, sale.startTime, sale.endTime, tf, sale.endDateRaw)
    : (sale.date || "TBD");

  // Expiration info
  const isExpired = sale.expiresAt && Date.now() > sale.expiresAt;
  const timeLeft = sale.expiresAt ? sale.expiresAt - Date.now() : null;
  const hoursLeft = timeLeft ? Math.max(0, Math.floor(timeLeft / 3600000)) : null;

  const openDirections = () => {
    const dest = `${sale.coords.lat},${sale.coords.lng}`;
    const orig = loc ? `${loc.lat},${loc.lng}` : "";
    window.open(`https://www.google.com/maps/dir/${orig}/${dest}`, "_blank");
  };

  const shareSale = () => setShowShare(true);

  const doDelete = () => {
    handleDeleteSale(sale.id);
    router.push("/");
  };

  return (
    <div>
      {/* Boost result banner */}
      {boostBanner === "success" && (
        <div className="px-4 py-3 flex items-center gap-2 text-white text-sm font-semibold" style={{ background: "linear-gradient(135deg, #d97706, #f59e0b)" }}>
          <Sparkles className="w-4 h-4 shrink-0" />
          Payment successful! Your sale is now boosted and featured.
        </div>
      )}
      {boostBanner === "cancelled" && (
        <div className="bg-stone-100 border-b border-stone-200 px-4 py-2.5 flex items-center gap-2 text-stone-600 text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />
          Boost checkout cancelled — no charge was made.
        </div>
      )}

      {/* Expired banner */}
      {isExpired && (
        <div className="bg-amber-50 border-b border-amber-200 px-4 py-2.5 flex items-center gap-2 text-amber-700 text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>This sale has ended</span>
        </div>
      )}

      {/* Photo gallery — swipeable on touch, arrow buttons on desktop */}
      <div
        className="relative h-72 bg-stone-200 overflow-hidden select-none"
        onTouchStart={(e) => {
          touchStartX.current = e.touches[0].clientX;
          touchStartY.current = e.touches[0].clientY;
        }}
        onTouchEnd={(e) => {
          const dx = e.changedTouches[0].clientX - (touchStartX.current ?? 0);
          const dy = e.changedTouches[0].clientY - (touchStartY.current ?? 0);
          // Only trigger swipe if horizontal motion dominates (avoid hijacking vertical scroll)
          if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) {
            const total = sale.photos?.length || 0;
            if (dx < 0 && photo < total - 1) setPhoto(photo + 1);
            if (dx > 0 && photo > 0) setPhoto(photo - 1);
          }
          touchStartX.current = null;
          touchStartY.current = null;
        }}
      >
        {/* Sliding strip of photos for smooth transitions */}
        {sale.photos?.length > 0 ? (
          <div
            className="absolute inset-0 flex transition-transform duration-300 ease-out"
            style={{ transform: `translateX(-${photo * 100}%)` }}
          >
            {sale.photos.map((src, i) => (
              <img
                key={i}
                src={src}
                alt=""
                draggable={false}
                className="w-full h-full object-cover shrink-0"
                style={{ width: "100%" }}
              />
            ))}
          </div>
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-emerald-400 to-lime-500 flex items-center justify-center">
            <span className="text-white/80 text-5xl">🏷️</span>
          </div>
        )}

        <button
          onClick={() => router.back()}
          className="absolute top-4 left-4 w-10 h-10 bg-black/40 backdrop-blur rounded-full flex items-center justify-center z-10"
        >
          <ChevronLeft className="w-6 h-6 text-white" />
        </button>
        <div className="absolute top-4 right-4 flex gap-2 z-10">
          <button onClick={shareSale}
            className="w-10 h-10 bg-black/40 backdrop-blur rounded-full flex items-center justify-center">
            <Share2 className="w-5 h-5 text-white" />
          </button>
          <button onClick={() => toggleSaved(sale.id)}
            className={`w-10 h-10 rounded-full flex items-center justify-center ${saved ? "bg-rose-500 text-white" : "bg-black/40 backdrop-blur text-white"}`}>
            <Heart className={`w-5 h-5 ${saved ? "fill-current" : ""}`} />
          </button>
        </div>

        {/* Left/right arrow buttons — only visible when there are multiple photos */}
        {(sale.photos?.length || 0) > 1 && (
          <>
            {photo > 0 && (
              <button
                onClick={() => setPhoto(photo - 1)}
                className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 bg-black/40 backdrop-blur rounded-full flex items-center justify-center hover:bg-black/55 transition z-10"
                aria-label="Previous photo"
              >
                <ChevronLeft className="w-5 h-5 text-white" />
              </button>
            )}
            {photo < (sale.photos.length - 1) && (
              <button
                onClick={() => setPhoto(photo + 1)}
                className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 bg-black/40 backdrop-blur rounded-full flex items-center justify-center hover:bg-black/55 transition z-10"
                aria-label="Next photo"
              >
                <ChevronRight className="w-5 h-5 text-white" />
              </button>
            )}
          </>
        )}

        {(sale.photos?.length || 0) > 1 && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 z-10">
            {sale.photos.map((_, i) => (
              <button key={i} onClick={() => setPhoto(i)}
                className={`h-2 rounded-full transition-all ${photo === i ? "bg-white w-6" : "bg-white/50 w-2"}`} />
            ))}
          </div>
        )}
        {/* Time remaining badge */}
        {hoursLeft !== null && !isExpired && hoursLeft < 48 && (
          <div className="absolute bottom-4 left-4 px-3 py-1 bg-amber-500 text-white text-xs font-bold rounded-full shadow z-10">
            {hoursLeft < 1 ? "Ending soon!" : `${hoursLeft}h left`}
          </div>
        )}
        {/* Featured (boosted) badge */}
        {saleBoosted && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 px-3 py-1.5 text-white text-xs font-bold rounded-full shadow z-10 flex items-center gap-1.5" style={{ background: "linear-gradient(135deg, #d97706, #f59e0b)" }}>
            <Sparkles className="w-3.5 h-3.5" /> Featured
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-6 space-y-5 pb-8">
        <div>
          <div className="flex items-start justify-between gap-3">
            <h1 className="text-xl font-bold text-stone-800 font-display">{sale.title}</h1>
            {distText && <span className="px-3 py-1 bg-emerald-100 text-emerald-700 text-sm font-bold rounded-full whitespace-nowrap">{distText}</span>}
          </div>
          {(() => {
            const st = getSaleType(sale.saleType);
            const STIcon = st.icon;
            const isEvent = sale.saleType === "event";
            return (
              <div className="inline-flex items-center gap-1.5 mt-2 px-3 py-1 rounded-full text-white text-xs font-bold" style={{ background: isEvent ? "linear-gradient(135deg, #7e22ce, #9333ea)" : "linear-gradient(135deg, #059669, #84cc16)" }}>
                <STIcon className="w-3.5 h-3.5" /> {st.label}
              </div>
            );
          })()}
          {sale.address && (
            <div className="flex items-center gap-1.5 text-stone-600 mt-2 text-sm">
              <MapPin className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>{sale.address}</span>
            </div>
          )}
          <div className="flex items-center gap-1.5 text-emerald-600 font-medium mt-1.5 text-sm">
            <Clock className="w-4 h-4" />{displayDate}
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {sale.tags?.map(t => <span key={t} className="px-3 py-1 bg-stone-100 text-stone-600 text-sm font-medium rounded-full">{t}</span>)}
        </div>

        <div>
          <h2 className="font-bold text-stone-800 mb-1.5 font-display">About This Sale</h2>
          <p className="text-stone-600 text-sm leading-relaxed">{sale.description}</p>
        </div>

        {/* Share — available to everyone */}
        <button onClick={() => setShowShare(true)}
          className="w-full py-3 bg-white border-2 border-emerald-200 text-emerald-700 font-semibold rounded-xl text-sm flex items-center justify-center gap-2 hover:bg-emerald-50 transition">
          <Share2 className="w-4 h-4" /> Share this sale
        </button>

        {/* Seller Card with Contact */}
        <div className="p-4 bg-stone-50 rounded-xl">
          <div className="flex items-center gap-4">
            <Avatar
              name={isOwner ? (profile?.name || sale.seller?.name) : sale.seller?.name}
              avatarUrl={isOwner ? (profile?.avatar_url || sale.seller?.avatarUrl) : sale.seller?.avatarUrl}
              avatarColor={isOwner ? (profile?.avatar_color || sale.seller?.avatarColor) : sale.seller?.avatarColor}
              size={48} className="shadow text-lg" />
            <div className="flex-1 min-w-0">
              <p className="font-bold text-stone-800">{isOwner ? (profile?.name || sale.seller?.name) : sale.seller?.name}</p>
              {isOwner ? (
                sale.seller?.reviewCount > 0 ? (
                  <button onClick={() => setShowReviews(true)} className="flex items-center gap-2 text-sm text-stone-500 hover:text-emerald-600 transition">
                    <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    {Number(sale.seller.rating).toFixed(1)} · {sale.seller.reviewCount} review{sale.seller.reviewCount !== 1 ? "s" : ""}
                  </button>
                ) : (
                  <span className="text-sm text-stone-400">This is your sale</span>
                )
              ) : (
                <button onClick={() => setShowReviews(true)} className="flex items-center gap-2 text-sm text-stone-500 hover:text-emerald-600 transition">
                  {sale.seller?.reviewCount > 0 ? (
                    <>
                      <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                      {Number(sale.seller.rating).toFixed(1)} · {sale.seller.reviewCount} review{sale.seller.reviewCount !== 1 ? "s" : ""}
                    </>
                  ) : (
                    <span className="text-emerald-600 font-medium">Be the first to review</span>
                  )}
                </button>
              )}
            </div>
          </div>
          {sale.seller?.bio && (
            <p className="text-stone-500 text-xs mt-3 leading-relaxed border-t border-stone-200 pt-3">"{sale.seller.bio}"</p>
          )}

          {/* Contact Seller */}
          {!isOwner && (
            <div className="mt-3 pt-3 border-t border-stone-200">
              {!showContact ? (
                <button onClick={() => setShowContact(true)}
                  className="w-full py-2.5 bg-white border border-emerald-200 text-emerald-700 font-semibold rounded-xl text-sm flex items-center justify-center gap-2 hover:bg-emerald-50 transition">
                  <MessageCircle className="w-4 h-4" /> Contact Seller
                </button>
              ) : (
                <div className="space-y-2">
                  {sale.seller?.phone && (
                    <a href={`tel:${sale.seller.phone}`}
                      className="w-full py-2.5 bg-emerald-600 text-white font-semibold rounded-xl text-sm flex items-center justify-center gap-2 hover:bg-emerald-700 transition">
                      <Phone className="w-4 h-4" /> Call {sale.seller.phone}
                    </a>
                  )}
                  <a href={`sms:${sale.seller?.phone || ""}?body=Hi! I'm interested in your yard sale "${sale.title}" on Yard$.`}
                    className="w-full py-2.5 bg-white border border-emerald-200 text-emerald-700 font-semibold rounded-xl text-sm flex items-center justify-center gap-2 hover:bg-emerald-50 transition">
                    <MessageCircle className="w-4 h-4" /> Text Message
                  </a>
                  {!sale.seller?.phone && (
                    <p className="text-xs text-stone-400 text-center">This seller hasn't added a phone number yet.</p>
                  )}
                  {/* Safety tip shown when contacting */}
                  <div className="flex items-start gap-2 mt-2 px-3 py-2.5 bg-amber-50 border border-amber-100 rounded-xl">
                    <Shield className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <p className="text-amber-800 text-xs leading-relaxed">
                      Stay safe: meet during daylight, bring a friend, and meet in a public spot when you can. Trust your instincts.
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Report — non-owners only, signed-in flow handled in modal */}
        {!isOwner && (
          <button onClick={() => setShowReport(true)}
            className="w-full py-2.5 text-stone-400 text-xs font-medium flex items-center justify-center gap-1.5 hover:text-stone-600 transition">
            <Flag className="w-3.5 h-3.5" /> Report this sale
          </button>
        )}

        {/* Owner actions */}
        {isOwner && (
          <>
            {/* View count — owner only */}
            <div className="flex items-center justify-center gap-2 py-2.5 bg-stone-50 rounded-xl text-stone-600 text-sm">
              <Eye className="w-4 h-4 text-emerald-600" />
              <span className="font-bold text-stone-800">{(sale.viewCount || 0).toLocaleString()}</span>
              <span>{sale.viewCount === 1 ? "view" : "views"}</span>
            </div>

            {/* Boost status / button */}
            {saleBoosted ? (
              <div className="flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold text-amber-800 border border-amber-300" style={{ background: "linear-gradient(135deg, #fffbeb, #fef3c7)" }}>
                <Sparkles className="w-4 h-4 text-amber-500" />
                Boosted — featured until {new Date(sale.boostedUntil).toLocaleDateString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}
              </div>
            ) : (
              <button onClick={() => setShowBoost(true)}
                className="w-full py-3.5 text-white font-bold rounded-xl shadow-lg hover:shadow-xl transition flex items-center justify-center gap-2"
                style={{ background: "linear-gradient(135deg, #d97706, #f59e0b)" }}>
                <Rocket className="w-5 h-5" /> Boost This Sale
              </button>
            )}

            <div className="flex gap-2">
              <button onClick={() => router.push(`/create?edit=${sale.id}`)}
                className="flex-1 py-3 bg-emerald-50 border border-emerald-200 text-emerald-700 font-semibold rounded-xl text-sm flex items-center justify-center gap-2 hover:bg-emerald-100 transition">
                <Edit className="w-4 h-4" /> Edit Sale
              </button>
              <button onClick={() => setConfirmDelete(true)}
                className="flex-1 py-3 bg-rose-50 border border-rose-200 text-rose-600 font-semibold rounded-xl text-sm flex items-center justify-center gap-2 hover:bg-rose-100 transition">
                <Trash2 className="w-4 h-4" /> Delete Sale
              </button>
            </div>
          </>
        )}

        {/* Delete confirmation */}
        {confirmDelete && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl">
            <p className="text-rose-700 font-medium text-sm mb-3">Are you sure you want to delete this sale? This can't be undone.</p>
            <div className="flex gap-2">
              <button onClick={() => setConfirmDelete(false)} className="flex-1 py-2.5 bg-white border border-stone-200 text-stone-600 font-medium rounded-lg text-sm">Cancel</button>
              <button onClick={doDelete} className="flex-1 py-2.5 bg-rose-600 text-white font-medium rounded-lg text-sm">Delete</button>
            </div>
          </div>
        )}

        {/* Featured Items */}
        {sale.featuredItems?.length > 0 && (
          <div>
            <h2 className="font-bold text-stone-800 mb-2 font-display">Featured Items</h2>
            <div className="space-y-2">
              {sale.featuredItems.map((item, i) => (
                <div key={i} className="flex items-center gap-3 p-3 bg-amber-50 border border-amber-200 rounded-xl">
                  <div className="w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center shrink-0">
                    <Star className="w-4 h-4 text-amber-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-stone-800 text-sm">{item.name}</p>
                    {item.price && <p className="text-amber-600 text-xs font-medium">${item.price}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Mini map */}
        <div>
          <h2 className="font-bold text-stone-800 mb-2 font-display">Location</h2>
          <MiniMap lat={sale.coords.lat} lng={sale.coords.lng} address={sale.address} />
        </div>

        <button onClick={openDirections}
          className="w-full py-4 text-white font-bold rounded-2xl flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transition"
          style={{ background: "linear-gradient(135deg, #059669, #84cc16)" }}>
          <Navigation className="w-5 h-5" /> Get Directions
        </button>
      </div>

      {/* Boost modal */}
      {showBoost && user && (
        <BoostModal sale={sale} user={user} onClose={() => setShowBoost(false)} />
      )}

      {/* Share modal */}
      {showShare && (
        <ShareModal sale={sale} onClose={() => setShowShare(false)} />
      )}

      {/* Report modal */}
      {showReport && (
        <ReportModal targetType="sale" sale={sale} onClose={() => setShowReport(false)} />
      )}

      {/* Reviews modal */}
      {showReviews && sale.seller?.id && (
        <ReviewsModal
          seller={sale.seller}
          saleId={sale.id}
          onClose={() => setShowReviews(false)}
          onChanged={() => { if (typeof loadSales === "function") loadSales(); }}
        />
      )}
    </div>
  );
}

function MiniMap({ lat, lng, address }) {
  const ref = useRef(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!ref.current) return;
    let map;
    try {
      const L = require("leaflet");
      map = L.map(ref.current, {
        center: [lat, lng], zoom: 16, zoomControl: false,
        dragging: false, scrollWheelZoom: false, doubleClickZoom: false, attributionControl: false,
      });
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19 }).addTo(map);
      const icon = L.divIcon({
        className: "sale-marker",
        html: `<div class="sale-marker-inner"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></div><div class="sale-marker-arrow"></div>`,
        iconSize: [40, 52], iconAnchor: [20, 52],
      });
      L.marker([lat, lng], { icon }).addTo(map);
      setLoaded(true);
    } catch {}
    return () => { if (map) map.remove(); };
  }, [lat, lng]);

  return (
    <div className="relative h-44 rounded-xl overflow-hidden shadow-inner border border-stone-200">
      <div ref={ref} className="absolute inset-0" />
      {address && loaded && (
        <div className="absolute bottom-2 left-2 bg-white/95 backdrop-blur rounded-lg px-2.5 py-1.5 text-[11px] text-stone-700 font-medium shadow z-[500]">
          📍 {address}
        </div>
      )}
    </div>
  );
}
